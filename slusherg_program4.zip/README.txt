Gavin Slusher
CS 344
Assignment 2

How to compile:
    - Type 'make' into the console to run the makefile.

How to run:
    - Type './line_processor' into the console 

Description of files:
- main.c contains logic to create, run, and wait for threads
- helpers.c contains logic for each actual thread, the buffers, and mutex logic
- helpers.h is a declaration file
